from setuptools import setup

setup(name='fixer-demo',
      version='0.1',
      description='Fixer service demo package',
      url='https://github.com/abe-solhjoo/freecurrencyapi',
      author='Ebrahim',
      author_email='ab.solhjoo@gmail.com',
      license='MIT',
      packages=['fixer'],
      zip_safe=False)
