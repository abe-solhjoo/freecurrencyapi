def get_rates():
    print("test")